#!/bin/sh

python3 ./FST.py $@


