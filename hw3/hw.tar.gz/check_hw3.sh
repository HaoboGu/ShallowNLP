#!/bin/sh
python /dropbox/17-18/570/check_hw.py /dropbox/17-18/570/languages /dropbox/17-18/570/hw3/submit-file-list hw.tar.gz
