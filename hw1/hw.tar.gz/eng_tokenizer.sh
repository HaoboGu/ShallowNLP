#!/bin/sh

python3 ./eng_tokenizer.py $@
