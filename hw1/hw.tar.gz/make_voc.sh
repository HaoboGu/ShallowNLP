#!/bin/sh

python3 ./make_voc.py $@
