#!/bin/sh

python3 ./MorphAcceptor2.py $@
