#!/bin/sh

python3 ./ExpandFSM2.py $@
