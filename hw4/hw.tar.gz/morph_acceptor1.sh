#!/bin/sh

python3 ./MorphAcceptor.py $@

