#!/bin/sh

python3 ./ExpandFSM.py $@


