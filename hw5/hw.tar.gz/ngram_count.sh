#!/bin/sh

python3 ./ngram_count.py $@
